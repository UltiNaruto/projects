#pragma once
#include <iostream>
#include <fstream>
#include <msclr/marshal.h>

namespace MapEditor {

	using namespace msclr::interop;
	using namespace System;
	using namespace System::Collections;
	using namespace System::Collections::Generic;
	using namespace System::ComponentModel;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
	using namespace System::Reflection;
	using namespace System::Windows::Forms;

	using std::ofstream;
	using std::ifstream;
	using std::ios;

	/// <summary>
	/// Description r�sum�e de Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: ajoutez ici le code du constructeur
			//
		}

	protected:
		/// <summary>
		/// Nettoyage des ressources utilis�es.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::MenuStrip^  menuStrip1;
	protected: 
	private: System::Windows::Forms::ToolStripMenuItem^  fichierToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  ouvrirCTRLOToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  sauvegarderCTRLSToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  quitterToolStripMenuItem;
	private: System::Windows::Forms::DataGridView^  dataGridView1;
	private: DataTable^ dataTable;
	private: System::Windows::Forms::OpenFileDialog^  openFileDialog1;
	private: System::Windows::Forms::SaveFileDialog^  saveFileDialog1;
	private: System::Windows::Forms::ToolStripMenuItem^  toolStripMenuItem1;
	private: System::Windows::Forms::ToolStripMenuItem^  typeDentit�ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  aProposDeToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  nouveauToolStripMenuItem;
			 //private: List<char[]> _dataArray = new List<char[]>();


	private:
		/// <summary>
		/// Variable n�cessaire au concepteur.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�thode requise pour la prise en charge du concepteur - ne modifiez pas
		/// le contenu de cette m�thode avec l'�diteur de code.
		/// </summary>
		void InitializeComponent(void)
		{
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle1 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->fichierToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->nouveauToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->ouvrirCTRLOToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->sauvegarderCTRLSToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->quitterToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->typeDentit�ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->aProposDeToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->openFileDialog1 = (gcnew System::Windows::Forms::OpenFileDialog());
			this->saveFileDialog1 = (gcnew System::Windows::Forms::SaveFileDialog());
			this->menuStrip1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->BeginInit();
			this->SuspendLayout();
			// 
			// menuStrip1
			// 
			this->menuStrip1->BackColor = System::Drawing::Color::BurlyWood;
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->fichierToolStripMenuItem, 
				this->toolStripMenuItem1});
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->RenderMode = System::Windows::Forms::ToolStripRenderMode::System;
			this->menuStrip1->Size = System::Drawing::Size(1018, 24);
			this->menuStrip1->TabIndex = 0;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// fichierToolStripMenuItem
			// 
			this->fichierToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {this->nouveauToolStripMenuItem, 
				this->ouvrirCTRLOToolStripMenuItem, this->sauvegarderCTRLSToolStripMenuItem, this->quitterToolStripMenuItem});
			this->fichierToolStripMenuItem->Name = L"fichierToolStripMenuItem";
			this->fichierToolStripMenuItem->Size = System::Drawing::Size(54, 20);
			this->fichierToolStripMenuItem->Text = L"Fichier";
			// 
			// nouveauToolStripMenuItem
			// 
			this->nouveauToolStripMenuItem->Name = L"nouveauToolStripMenuItem";
			this->nouveauToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::N));
			this->nouveauToolStripMenuItem->Size = System::Drawing::Size(179, 22);
			this->nouveauToolStripMenuItem->Text = L"Nouveau";
			this->nouveauToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::nouveauToolStripMenuItem_Click);
			// 
			// ouvrirCTRLOToolStripMenuItem
			// 
			this->ouvrirCTRLOToolStripMenuItem->Name = L"ouvrirCTRLOToolStripMenuItem";
			this->ouvrirCTRLOToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::O));
			this->ouvrirCTRLOToolStripMenuItem->Size = System::Drawing::Size(179, 22);
			this->ouvrirCTRLOToolStripMenuItem->Text = L"Ouvrir";
			this->ouvrirCTRLOToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::ouvrirCTRLOToolStripMenuItem_Click);
			// 
			// sauvegarderCTRLSToolStripMenuItem
			// 
			this->sauvegarderCTRLSToolStripMenuItem->Name = L"sauvegarderCTRLSToolStripMenuItem";
			this->sauvegarderCTRLSToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::S));
			this->sauvegarderCTRLSToolStripMenuItem->Size = System::Drawing::Size(179, 22);
			this->sauvegarderCTRLSToolStripMenuItem->Text = L"Sauvegarder";
			this->sauvegarderCTRLSToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::sauvegarderCTRLSToolStripMenuItem_Click);
			// 
			// quitterToolStripMenuItem
			// 
			this->quitterToolStripMenuItem->Name = L"quitterToolStripMenuItem";
			this->quitterToolStripMenuItem->Size = System::Drawing::Size(179, 22);
			this->quitterToolStripMenuItem->Text = L"Quitter";
			// 
			// toolStripMenuItem1
			// 
			this->toolStripMenuItem1->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->typeDentit�ToolStripMenuItem, 
				this->aProposDeToolStripMenuItem});
			this->toolStripMenuItem1->Name = L"toolStripMenuItem1";
			this->toolStripMenuItem1->Size = System::Drawing::Size(24, 20);
			this->toolStripMenuItem1->Text = L"\?";
			// 
			// typeDentit�ToolStripMenuItem
			// 
			this->typeDentit�ToolStripMenuItem->Name = L"typeDentit�ToolStripMenuItem";
			this->typeDentit�ToolStripMenuItem->Size = System::Drawing::Size(147, 22);
			this->typeDentit�ToolStripMenuItem->Text = L"Type d\'entit�";
			this->typeDentit�ToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::typeDentit�ToolStripMenuItem_Click);
			// 
			// aProposDeToolStripMenuItem
			// 
			this->aProposDeToolStripMenuItem->Name = L"aProposDeToolStripMenuItem";
			this->aProposDeToolStripMenuItem->Size = System::Drawing::Size(147, 22);
			this->aProposDeToolStripMenuItem->Text = L"A propos de...";
			this->aProposDeToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::aProposDeToolStripMenuItem_Click);
			// 
			// dataGridView1
			// 
			this->dataGridView1->AllowUserToAddRows = false;
			this->dataGridView1->AllowUserToDeleteRows = false;
			this->dataGridView1->AllowUserToResizeColumns = false;
			this->dataGridView1->AllowUserToResizeRows = false;
			this->dataGridView1->ColumnHeadersBorderStyle = System::Windows::Forms::DataGridViewHeaderBorderStyle::Single;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::DisableResizing;
			this->dataGridView1->Location = System::Drawing::Point(12, 27);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->RowHeadersBorderStyle = System::Windows::Forms::DataGridViewHeaderBorderStyle::Single;
			dataGridViewCellStyle1->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleCenter;
			dataGridViewCellStyle1->BackColor = System::Drawing::SystemColors::Control;
			dataGridViewCellStyle1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			dataGridViewCellStyle1->ForeColor = System::Drawing::SystemColors::WindowText;
			dataGridViewCellStyle1->SelectionBackColor = System::Drawing::SystemColors::Highlight;
			dataGridViewCellStyle1->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
			dataGridViewCellStyle1->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
			this->dataGridView1->RowHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this->dataGridView1->RowHeadersWidth = 4;
			this->dataGridView1->RowHeadersWidthSizeMode = System::Windows::Forms::DataGridViewRowHeadersWidthSizeMode::DisableResizing;
			this->dataGridView1->Size = System::Drawing::Size(994, 440);
			this->dataGridView1->TabIndex = 1;
			// 
			// openFileDialog1
			// 
			this->openFileDialog1->DefaultExt = L"*.bin";
			// 
			// saveFileDialog1
			// 
			this->saveFileDialog1->DefaultExt = L"*.bin";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1018, 476);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->menuStrip1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedToolWindow;
			this->MainMenuStrip = this->menuStrip1;
			this->Name = L"Form1";
			this->ShowIcon = false;
			this->Text = L"Map Editor For UltiNaruto Counter-Strike 2D";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: void InitDataTable() {
				 dataTable = gcnew DataTable();
				 dataTable->Rows->Clear();
				 dataTable->Columns->Clear();
				 while (dataTable->Rows->Count != 19)
				 {
					 dataTable->Rows->Add();
				 }
				 while (dataTable->Columns->Count != 78)
				 {
					 dataTable->Columns->Add();
				 }
				 for(int x=0;x<78;x++)
				 {
					 for(int y=0;y<19;y++)
					 {
						 dataTable->Rows[y][x] = "1";
						 char strX[4] = {0};
						 sprintf(strX, "%d", x);
						 dataTable->Columns[x]->ColumnName = gcnew String(strX);
					 }
				 }
				 dataGridView1->DataSource = dataTable;
				 dataGridView1->AutoResizeColumns();
				 for(int x=0;x<78;x++)
				 {
					 for(int y=0;y<19;y++)
					 {
						 dataTable->Rows[y][x] = "";
					 }
				 }
				 dataGridView1->DataSource = dataTable;
			 }
	private: void LoadMap(char * filename) {
				 char * mapArray = new char[20*78];
				 ifstream file;
				 file.open(filename, ios::in|ios::binary);
				 file.read(mapArray, 20*78);
				 file.close();
				 for(int x=0;x<78;x++)
				 {
					 for(int y=0;y<19;y++)
					 {
						 char value[4] = {0};
						 sprintf(value, "%d", mapArray[x*20+y]);
						 String^ strValue = gcnew String(value);
						 if(mapArray[x*20+y] == 0x01)
							 dataTable->Rows[y][x] = "";
						 else
							 dataTable->Rows[y][x] = strValue;
					 }
				 }
				 dataGridView1->DataSource = dataTable;
				 dataGridView1->AutoResizeColumns();
			 }
	private: void SaveMap(char * filename) {
				 dataGridView1->Refresh();
				 dataTable = ((DataTable^)dataGridView1->DataSource)->Copy();
				 marshal_context ^ context = gcnew marshal_context();
				 char * mapArray = new char[20*78];
				 for(int x=0;x<78;x++)
				 {
					 for(int y=0;y<19;y++)
					 {
						 if(dataTable->Rows[y][x] == "")
							 mapArray[x*20+y] = 0x01;
						 else
							 mapArray[x*20+y] = atoi((char*)context->marshal_as<const char*>((String^)dataTable->Rows[y][x]));
					 }
					 mapArray[x*20+19] = 1;
				 }
				 ofstream file;
				 file.open(filename, ios::out|ios::trunc|ios::binary);
				 file.write(mapArray, 20*78);
				 file.close();
				 dataGridView1->DataSource = dataTable;
			 }
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
				 InitDataTable();
			 }
	private: System::Void ouvrirCTRLOToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
				 if(openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)
				 {
					 marshal_context ^ context = gcnew marshal_context();
					 char * filename = (char*)context->marshal_as<const char*>(openFileDialog1->FileName);
					 LoadMap(filename);
				 }
			 }
	private: System::Void sauvegarderCTRLSToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
				 if(saveFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)
				 {
					 marshal_context ^ context = gcnew marshal_context();
					 char * filename = (char*)context->marshal_as<const char*>(saveFileDialog1->FileName);
					 SaveMap(filename);
				 }
			 }
	private: System::Void typeDentit�ToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
				 MessageBox::Show("Mur - 2\nPoint de r�apparition - 3");
			 }
	private: System::Void aProposDeToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
				 MessageBox::Show("Cet �diteur de map a �t� cr�� par UltiNaruto pour le jeu UltiNaruto Counter-Strike 2D");
			 }
	private: System::Void nouveauToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
				 InitDataTable();
			 }
	private: System::Void onKeyPress(Object^ sender, KeyPressEventArgs^ e) {
				 if(e->KeyChar == '\b')
				 {
					 dataGridView1->CurrentCell->Value = "";
				 }
			 }
	};
}

