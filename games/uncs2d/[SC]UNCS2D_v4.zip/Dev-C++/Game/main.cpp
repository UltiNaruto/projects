#pragma warning(disable:4996)
#pragma warning(disable:4244)
#include <conio.h>
#include <stdlib.h>
#include <iostream>
#include <time.h>
#include <windows.h>

using std::cout;
using std::cin;
using std::endl;
using std::ofstream;
using std::ifstream;
using std::ios;

#define VK_A 0x41
#define VK_E 0x45
#define VK_L 0x4C
#define VK_M 0x4D
#define VK_Q 0x51
#define VK_D 0x44
#define VK_Z 0x5A
#define VK_S 0x53

#define LEFT_BORDER 0
#define RIGHT_BORDER 79
#define TOP_BORDER 2
#define BOTTOM_BORDER 22

struct PLAYER {
	int x;
	int y;
	int vertical;
	int horizontal;
	int health;
	bool isDead;
	int kills;
	int deaths;
	int currentweaponid;
};

struct WEAPON {
	char name[20];
	int damage;
	int range;
};

struct WALL {
	int x;
	int y;
};

struct SPAWNPOINTS {
	int x;
	int y;
};

bool end_game = false;
int respawn_time = 3;
int frag_limit;
int winner_id;
int key;
PLAYER Player[3];
WEAPON WeaponMgr[11];
WALL Walls[20*78];
SPAWNPOINTS spawnpoints[20*78];
int weapon_count=1;
int spawnpoints_count=0;
int wall_count=0;
char mapName[MAX_PATH] = {0};
void InitWall(int x, int y);
void InitSpawnpoint(int x, int y);

#include "CUtils.h"

void MessageBoxMyPos(int x, int y)
{
	char msg[100];
	sprintf(msg, "X : %d\nY : %d", x, y);
	MessageBoxA(0,msg, "UltiNaruto Counter-Strike 2D v3.0", 0);
}

void InitPlayer(int player_id, int x, int y, int health, int currentweaponid, bool firstSpawn=false)
{
	Player[player_id].x = x;
	Player[player_id].y = y;
	Player[player_id].horizontal = 0;
	Player[player_id].vertical = 0;
	Player[player_id].health = health;
	Player[player_id].isDead = false;
	Player[player_id].currentweaponid = currentweaponid;
	if(firstSpawn)
	{
		Player[player_id].kills = 0;
		Player[player_id].deaths = 0;
	}
}

void InitSpawnpoint(int x, int y)
{
	spawnpoints[spawnpoints_count].x = x;
	spawnpoints[spawnpoints_count].y = y;
	spawnpoints_count++;
}

void InitWall(int x, int y)
{
	Walls[wall_count].x = x;
	Walls[wall_count].y = y;
	wall_count++;
}

void InitWeapon(char * name, int damage, int range)
{
	strcpy(WeaponMgr[weapon_count].name, name);
	WeaponMgr[weapon_count].damage = damage;
	WeaponMgr[weapon_count].range = range;
	weapon_count++;
}

void Shoot(int player_id,int enemy_id,int shoot_x,int shoot_y,int shoot_horizontal,int shoot_vertical)
{
	int i;
	if (shoot_horizontal == -1)
	{
		for(i=1;i<(WeaponMgr[Player[player_id].currentweaponid].range+1);i++)
		{
			if (shoot_x-i > 0)
			{
				if(i>1)
				{
					gotoxy((LEFT_BORDER+1)+shoot_x-i+1,(TOP_BORDER+1)+shoot_y);
					cout << " ";
				}
				for (int j=0;j<(wall_count+1);j++)
					if (Walls[j].x == shoot_x-i && Walls[j].y == shoot_y)
						return;
				if (Player[enemy_id].x == shoot_x-i && Player[2].y == shoot_y)
				{
					if (Player[enemy_id].health > 0)
					{
						if (i == 1)
							Player[enemy_id].health -= (int)(WeaponMgr[Player[player_id].currentweaponid].damage / 1.5);
						else
							Player[enemy_id].health -= (int)(WeaponMgr[Player[player_id].currentweaponid].damage / i); 
					}

					return;
				}
				gotoxy((LEFT_BORDER+1)+shoot_x-i,(TOP_BORDER+1)+shoot_y);
				cout << "-";
			}
			else
				break;
			Sleep(20);
		}

		gotoxy((LEFT_BORDER+1)+shoot_x-i+1,(TOP_BORDER+1)+shoot_y);
		cout << " ";
	}
	if (shoot_horizontal == 1)
	{
		for(i=1;i<(WeaponMgr[Player[player_id].currentweaponid].range+1);i++)
		{
			if (shoot_x+i < 77)
			{
				if(i>1)
				{
					gotoxy((LEFT_BORDER+1)+shoot_x+i-1,(TOP_BORDER+1)+shoot_y);
					cout << " ";
				}
				for (int j=0;j<(wall_count+1);j++)
					if (Walls[j].x == shoot_x+i && Walls[j].y == shoot_y)
						return;
				if (Player[enemy_id].x == shoot_x+i && Player[2].y == shoot_y)
				{
					if (Player[enemy_id].health > 0)
					{
						if (i == 1)
							Player[enemy_id].health -= (int)(WeaponMgr[Player[player_id].currentweaponid].damage / 1.5);
						else
							Player[enemy_id].health -= (int)(WeaponMgr[Player[player_id].currentweaponid].damage / i); // damage p2   
					}

					return;
				}
				gotoxy((LEFT_BORDER+1)+shoot_x+i,(TOP_BORDER+1)+shoot_y);
				cout << "-";
			}
			else
				break;
			Sleep(20);
		}
		gotoxy((LEFT_BORDER+1)+shoot_x+i-1,(TOP_BORDER+1)+shoot_y);
		cout << " ";
	}
	if (shoot_vertical == -1)
	{
		for(i=1;i<(WeaponMgr[Player[player_id].currentweaponid].range+1);i++)
		{
			if (shoot_y-i > 0)
			{
				if(i>1)
				{
					gotoxy((LEFT_BORDER+1)+shoot_x,(TOP_BORDER+1)+shoot_y-i+1);
					cout << " ";
				}
				for (int j=0;j<(wall_count+1);j++)
					if (Walls[j].x == shoot_x && Walls[j].y == shoot_y-i)
						return;
				if (Player[enemy_id].x == shoot_x && Player[enemy_id].y == shoot_y-i)
				{
					if (Player[enemy_id].health > 0)
					{
						if (i == 1)
							Player[enemy_id].health -= (int)(WeaponMgr[Player[player_id].currentweaponid].damage / 1.5);
						else
							Player[enemy_id].health -= (int)(WeaponMgr[Player[1].currentweaponid].damage / i);  
					}

					return;
				}
				else
					break;
				gotoxy((LEFT_BORDER+1)+shoot_x,(TOP_BORDER+1)+shoot_y-i);
				cout << "|";
			}
			Sleep(20);
		}
		gotoxy((LEFT_BORDER+1)+shoot_x,(TOP_BORDER+1)+shoot_y-i+1);
		cout << " ";
	}
	if (shoot_vertical == 1)
	{
		for(i=1;i<(WeaponMgr[Player[player_id].currentweaponid].range+1);i++)
		{
			if (shoot_y+i < 18)
			{
				if(i>1)
				{
					gotoxy((LEFT_BORDER+1)+shoot_x,(TOP_BORDER+1)+shoot_y+i-1);
					cout << " ";
				}
				for (int j=0;j<(wall_count+1);j++)
					if (Walls[j].x == shoot_x && Walls[j].y == shoot_y+i)
						return;
				if (Player[enemy_id].x == shoot_x && Player[enemy_id].y == shoot_y+i)
				{
					if (Player[enemy_id].health > 0)
					{
						if (i == 1)
							Player[enemy_id].health -= (int)(WeaponMgr[Player[player_id].currentweaponid].damage / 1.5);
						else
							Player[enemy_id].health -= (int)(WeaponMgr[Player[player_id].currentweaponid].damage / i);  
					}
					else
						break;
					gotoxy((LEFT_BORDER+1)+shoot_x,(TOP_BORDER+1)+shoot_y-i);
					cout << "|";

					return;
				}
			}
			else
				break;
			Sleep(20);
		}
		gotoxy((LEFT_BORDER+1)+shoot_x,(TOP_BORDER+1)+shoot_y+i-1);
		cout << " ";
	}
}

void Render()
{
	system("cls"); 
	gotoxy(0,TOP_BORDER);
	cout << "+------------------------------------------------------------------------------+";
	for (int i=3; i<23 ;i++)
	{
		gotoxy(LEFT_BORDER,i);
		cout << "|";
		gotoxy(RIGHT_BORDER,i);
		cout << "|";
	}
	gotoxy(0,BOTTOM_BORDER);
	cout << "+------------------------------------------------------------------------------+";
	for(int i=0;i<(wall_count+1);i++)
	{
		gotoxy((LEFT_BORDER+1)+Walls[i].x, (TOP_BORDER+1)+Walls[i].y);
		printf("#");
	}	
}

void Hotkeys()
{
	/*if (GetAsyncKeyState(VK_F2)<0)
	MessageBoxMyPos(Player[1].x, Player[1].y);*/

	if (GetAsyncKeyState(VK_ESCAPE)<0)
		ExitProcess(0);

	// Player 1

	if (GetAsyncKeyState(VK_SPACE)<0)
		Shoot(1,2,Player[1].x,Player[1].y,Player[1].horizontal,Player[1].vertical);

	if (GetAsyncKeyState(VK_Q)<0)
	{
		if (Player[1].x > 0)
		{
			for(int i=0;i<(wall_count+1);i++)
				if ((Player[1].x - 1 == Walls[i].x && Player[1].y == Walls[i].y) || (Player[1].x - 1 == Player[2].x && Player[1].y == Player[2].y))
					return;

			gotoxy((LEFT_BORDER+1)+Player[1].x, (TOP_BORDER+1)+Player[1].y);
			cout << " ";
			Player[1].horizontal = -1;
			Player[1].vertical = 0;
			Player[1].x -= 1;
		}
	}
	if (GetAsyncKeyState(VK_D)<0)
	{
		if (Player[1].x < 77)
		{
			for(int i=0;i<(wall_count+1);i++)
				if ((Player[1].x + 1 == Walls[i].x && Player[1].y == Walls[i].y) || (Player[1].x + 1 == Player[2].x && Player[1].y == Player[2].y))
					return;

			gotoxy((LEFT_BORDER+1)+Player[1].x, (TOP_BORDER+1)+Player[1].y);
			cout << " ";
			Player[1].horizontal = 1;
			Player[1].vertical = 0;
			Player[1].x += 1;
		}
	}
	if (GetAsyncKeyState(VK_Z)<0)
	{
		if (Player[1].y > 0)
		{
			for(int i=0;i<(wall_count+1);i++)             
				if ((Player[1].x == Walls[i].x && Player[1].y - 1 == Walls[i].y) || (Player[1].x == Player[2].x && Player[1].y - 1 == Player[2].y))
					return;

			gotoxy((LEFT_BORDER+1)+Player[1].x, (TOP_BORDER+1)+Player[1].y);
			cout << " ";
			Player[1].horizontal = 0;
			Player[1].vertical = -1;
			Player[1].y -= 1;
		}
	}
	if (GetAsyncKeyState(VK_S)<0)
	{
		if (Player[1].y < 18)
		{
			for(int i=0;i<(wall_count+1);i++)
				if ((Player[1].x == Walls[i].x && Player[1].y + 1 == Walls[i].y) || (Player[1].x == Player[2].x && Player[1].y + 1 == Player[2].y))
					return;

			gotoxy((LEFT_BORDER+1)+Player[1].x, (TOP_BORDER+1)+Player[1].y);
			cout << " ";
			Player[1].horizontal = 0;
			Player[1].vertical = 1;
			Player[1].y += 1;
		}
	}

	if (GetAsyncKeyState(VK_A)<0)
		if (Player[1].currentweaponid > 1)
			Player[1].currentweaponid -= 1;

	if (GetAsyncKeyState(VK_E)<0)
		if (Player[1].currentweaponid < 10)
			Player[1].currentweaponid += 1;

	// Player 2

	if (GetAsyncKeyState(VK_RCONTROL)<0)
		Shoot(2,1,Player[2].x,Player[2].y,Player[2].horizontal,Player[2].vertical);

	if (GetAsyncKeyState(VK_LEFT)<0)
	{
		if (Player[2].x > 0)
		{
			for(int i=0;i<(wall_count+1);i++)
				if ((Player[2].x - 1 == Walls[i].x && Player[2].y == Walls[i].y) || (Player[2].x - 1 == Player[1].x && Player[2].y == Player[1].y))
					return;

			gotoxy((LEFT_BORDER+1)+Player[2].x, (TOP_BORDER+1)+Player[2].y);
			cout << " ";
			Player[2].horizontal = -1;
			Player[2].vertical = 0;
			Player[2].x -= 1;
		}
	}
	if (GetAsyncKeyState(VK_RIGHT)<0)
	{
		if (Player[2].x < 77)
		{
			for(int i=0;i<(wall_count+1);i++)
				if ((Player[2].x + 1 == Walls[i].x && Player[2].y == Walls[i].y) || (Player[2].x + 1 == Player[1].x && Player[2].y == Player[1].y))
					return;

			gotoxy((LEFT_BORDER+1)+Player[2].x, (TOP_BORDER+1)+Player[2].y);
			cout << " ";
			Player[2].horizontal = 1;
			Player[2].vertical = 0;
			Player[2].x += 1;
		}
	}
	if (GetAsyncKeyState(VK_UP)<0)
	{
		if (Player[2].y > 0)
		{
			for(int i=0;i<(wall_count+1);i++)
				if ((Player[2].x == Walls[i].x && Player[2].y - 1 == Walls[i].y) || (Player[2].x == Player[1].x && Player[2].y - 1 == Player[1].y))
					return;

			gotoxy((LEFT_BORDER+1)+Player[2].x, (TOP_BORDER+1)+Player[2].y);
			cout << " ";
			Player[2].horizontal = 0;
			Player[2].vertical = -1;
			Player[2].y -= 1;
		}
	}
	if (GetAsyncKeyState(VK_DOWN)<0)
	{
		if (Player[2].y < 18)
		{
			for(int i=0;i<(wall_count+1);i++)
				if ((Player[2].x == Walls[i].x && Player[2].y + 1 == Walls[i].y) || (Player[2].x == Player[1].x && Player[2].y + 1 == Player[1].y))
					return;

			gotoxy((LEFT_BORDER+1)+Player[2].x, (TOP_BORDER+1)+Player[2].y);
			cout << " ";
			Player[2].horizontal = 0;
			Player[2].vertical = 1;
			Player[2].y += 1;
		}
	}

	if (GetAsyncKeyState(VK_L)<0)
		if (Player[2].currentweaponid > 1)
			Player[2].currentweaponid -= 1;

	if (GetAsyncKeyState(VK_M)<0)
		if (Player[2].currentweaponid < 10)
			Player[2].currentweaponid += 1;
}

int main(int argc, char *argv[])
{
	srand(time(NULL));
	SetConsoleTitle("UltiNaruto Counter-Strike 2D v4.0");
	cout << "Limite de Kills? (entre 20-100)\n";
	scanf("%d", &frag_limit);
	cout << "Choisissez une map? (ID de la map requis)\n";
	int id;
	scanf("%d", &id);
	sprintf(mapName, "maps\\map%d.bin", id);
	if (frag_limit < 20)
	{
		frag_limit = 20;
	}
	if (frag_limit > 100)
	{
		frag_limit = 100;
	}
	InitPlayer(1, 1, 3, 100, 1, true);
	InitPlayer(2, 76, 15, 100, 1, true);
	InitWeapon("M4A1", 100, 5);
	InitWeapon("Desert Eagle", 180, 2);
	InitWeapon("MP5", 76, 4);
	InitWeapon("Anaconda", 168, 2);
	InitWeapon("XM8", 94, 6);
	InitWeapon("AK-47", 116, 6);
	InitWeapon("Kriss Super V", 79, 5);
	InitWeapon("Knife", 90, 1);
	InitWeapon("M60", 106, 8);
	InitWeapon("P90", 68, 4);
	if(!loadMap(mapName))
		loadMap("maps\\map_default.bin");
	LogRawMapFile("maps\\map_dump.bin", dumpMapFromWallArray(Walls, wall_count, spawnpoints));
	//LogSpawnpointsPtr(spawnpoints, spawnpoints_count);
	Render();
	while(!end_game)
	{       
		gotoxy(21,0);
		cout << "   ";
		gotoxy(74,0);
		cout << "   ";
		gotoxy(0,0);
		cout << "Player 1 :      HP : " << Player[1].health << "                             Player 2 :      HP : " << Player[2].health << "\nKills : " << Player[1].kills << "     Deaths : " << Player[1].deaths << "                             Kills : " << Player[2].kills << "     Deaths : " << Player[2].deaths;
		gotoxy(17,23);
		cout << "                    ";
		gotoxy(52,23);
		cout << "                          ";
		gotoxy(0,23);
		cout << "Current Weapon : " << WeaponMgr[Player[1].currentweaponid].name << "                  " << "Current Weapon : " << WeaponMgr[Player[2].currentweaponid].name;
		char fragLimitText[256] = {0};
		sprintf(fragLimitText, "Frag Limit : %d", frag_limit);
		gotoxy(RIGHT_BORDER/2-strlen(fragLimitText)/2,0);
		printf(fragLimitText);
		int random = (rand()%spawnpoints_count);
		Hotkeys();
		if (Player[1].isDead == false)
		{
			gotoxy((LEFT_BORDER+1)+Player[1].x, (TOP_BORDER+1)+Player[1].y);
			cout << "1";
		}
		if (Player[2].isDead == false)
		{
			gotoxy((LEFT_BORDER+1)+Player[2].x, (TOP_BORDER+1)+Player[2].y);
			cout << "2";
		}
		for (int i=1;i<3;i++)
		{
			if (Player[i].kills >= frag_limit)
			{
				winner_id = i;
				break;
			}
			if (Player[i].health <= 0)
			{
				gotoxy((LEFT_BORDER+1)+Player[i].x, (TOP_BORDER+1)+Player[i].y);
				cout << " ";
				int j;
				if (i==1)
					j = 2;
				else if (i==2)
					j = 1;
				Player[j].kills += 1;
				Player[i].deaths += 1;
				InitPlayer(i, spawnpoints[random].x, spawnpoints[random].y, 100, Player[i].currentweaponid);
			}
		}

		Sleep(100); // Rafraichissement tous les 100 ms
	}
	while (!_kbhit())
	{
		system("cls");
		gotoxy(0,0);
		cout << "Player " << winner_id << " won!";
		Sleep(100); // Rafraichissement tous les 100 ms
	}
	return EXIT_SUCCESS;
}
