#include <fstream>

void LogWallsPtr(WALL * Walls, int wall_count)
{
	ofstream file;
	file.open("WallsPtr.log", ios::trunc);
	for(int i=0;i<(wall_count+1);i++)
	{
		file << "Walls[" << i << "] : " << endl;
		file << "     X : " << Walls[i].x << endl;
		file << "     Y : " << Walls[i].y << endl << endl;
	}
}

void LogSpawnpointsPtr(SPAWNPOINTS * spawnpoints, int spawnpoints_count)
{
	ofstream file;
	file.open("SpawnpointsPtr.log", ios::trunc);
	for(int i=0;i<(spawnpoints_count+1);i++)
	{
		file << "spawnpoints[" << i << "] : " << endl;
		file << "     X : " << spawnpoints[i].x << endl;
		file << "     Y : " << spawnpoints[i].y << endl << endl;
	}
}

char * dumpMapFromWallArray(WALL * walls, int wallCount, SPAWNPOINTS * spawnpoints)
{
	char * map = new char[19*78];
	for(int x=0;x<20;x++)
	{
		for(int y=0;y<20;y++)
		{
			map[x*20+y] = 1;
		}
	}
	for(int i=0;i<(wallCount+1);i++)
	{
		for(int x=0;x<20;x++)
		{
			for(int y=0;y<20;y++)
			{
				if(walls[i].x == x && walls[i].y == y)
				{
					map[x*20+y] = 2;
				}
			}
		}
	}
	for(int i=0;i<(spawnpoints_count+1);i++)
	{
		for(int x=(LEFT_BORDER+1);x<(78+(LEFT_BORDER+1));x++)
		{
			for(int y=(TOP_BORDER+1);y<(20+(TOP_BORDER+1));y++)
			{
				if(spawnpoints[i].x == x && spawnpoints[i].y == y)
				{
					map[x*20+y] = 3;
				}
			}
		}
	}
	return map;
}

char * getRawMapContents(char * filename)
{
	char * map = new char[20*78];
	ZeroMemory(map, 20*78);
	ifstream file(filename, ios::in|ios::binary);
	if(file.is_open())
	{
		file.read(map, 20*78);
		file.close();
		return map;
	}
	return NULL;
}

bool loadMap(char * filename)
{
	char * map = getRawMapContents(filename);
	if(map == NULL)
		return false;
	for(int x=0;x<78;x++)
	{
		for(int y=0;y<20;y++)
	    {
			if(map[x*20+y] == 2)
			{
				InitWall(x,y);
            }
            
            if(map[x*20+y] == 3)
			{
				InitSpawnpoint(x,y);
            }
        }
    }
	return true;
}

void LogRawMapFile(char * filename, char * map)
{
	ofstream file;
	file.open(filename, ios::out|ios::trunc|ios::binary);
	for(int x=0;x<78;x++)
	{
		for(int y=0;y<20;y++)
		{
			file << map[x*20+y];
		}
	}
	file.close();
}

void gotoxy(int x, int y) {
	COORD pos = {x, y};
	HANDLE output = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleCursorPosition(output, pos);
}

struct Vec2D {
	long x,y;
};
