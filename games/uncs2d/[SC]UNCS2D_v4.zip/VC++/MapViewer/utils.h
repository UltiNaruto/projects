#include <fstream>

void gotoxy(int x, int y) {
	COORD pos = {x, y};
	HANDLE output = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleCursorPosition(output, pos);
}

char * getRawMapContents(char * filename)
{
	char * map = new char[20*78];
	ifstream file;
	file.open(filename, ios::in|ios::binary);
	file.read(map, 20*78);
	file.close();
	return map;
}