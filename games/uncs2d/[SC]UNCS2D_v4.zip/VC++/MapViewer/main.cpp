#pragma warning(disable:4996)
#include <conio.h>
#include <stdlib.h>
#include <iostream>
#include <time.h>
#include <windows.h>

using std::cout;
using std::cin;
using std::endl;
using std::ifstream;
using std::ios;

#define LEFT_BORDER 0
#define RIGHT_BORDER 79
#define TOP_BORDER 2
#define BOTTOM_BORDER 22

#include "utils.h"

char mapName[MAX_PATH];

void Render()
{
	system("cls"); 
	gotoxy(0,TOP_BORDER);
	cout << "+------------------------------------------------------------------------------+";
	for (int i=3; i<23 ;i++)
	{
		gotoxy(LEFT_BORDER,i);
		cout << "|";
		gotoxy(RIGHT_BORDER,i);
		cout << "|";
	}
	gotoxy(0,BOTTOM_BORDER);
	cout << "+------------------------------------------------------------------------------+";
	char * map = getRawMapContents(mapName);
	for(int x=0;x<78;x++)
	{
		for(int y=0;y<20;y++)
		{
			if(map[x*20+y] == 2)
			{
				gotoxy((LEFT_BORDER+1)+x,(TOP_BORDER+1)+y);
				printf("#");
			}
			if(map[x*20+y] == 3)
			{
				gotoxy((LEFT_BORDER+1)+x,(TOP_BORDER+1)+y);
				printf("S");
			}
		}
	}
	gotoxy(RIGHT_BORDER/2-strlen("Map Viewer")/2,0);
	printf("Map Viewer");
	gotoxy(RIGHT_BORDER, BOTTOM_BORDER+1);
}

int main(int argc, char *argv[])
{
	SetConsoleTitle("Map Viewer for UltiNaruto Counter-Strike 2D");
	cout << "Quel map voulez-vouz charger? (ID de la map requis)\n";
	int id;
	scanf("%d", &id);
	sprintf(mapName, "maps\\map%d.bin", id);
	Render();
	while(!_kbhit())
		Sleep(100);

	return EXIT_SUCCESS;
}