#include <conio.h>
#include <stdlib.h>
#include <iostream>
#include <time.h>
#include <windows.h>

using std::cout;
using std::cin;
using std::endl;
using std::ofstream;
using std::ios;

#define VK_A 0x41
#define VK_E 0x45
#define VK_L 0x4C
#define VK_M 0x4D
#define VK_Q 0x51
#define VK_D 0x44
#define VK_Z 0x5A
#define VK_S 0x53

#define LEFT_BORDER 0
#define RIGHT_BORDER 79
#define TOP_BORDER 2
#define BOTTOM_BORDER 22

struct PLAYER {
       int x;
       int y;
       int vertical;
       int horizontal;
       int health;
       bool isDead;
       int kills;
       int deaths;
       int currentweaponid;
};

struct WEAPON {
       char name[20];
       int damage;
       int range;
};

struct WALL {
       int x;
       int y;
};

struct SPAWNPOINTS {
       int x;
       int y;
};

bool end_game = false;
int respawn_time = 3;
int frag_limit;
int winner_id;
int key;
PLAYER Player[3];
WEAPON WeaponMgr[11];
WALL Walls[147];
SPAWNPOINTS spawnpoints[8];
int weapon_count=1;
int wall_count=147;
int wall_id=0;

void MessageBoxMyPos(int x, int y)
{
     char msg[100];
     sprintf(msg, "X : %d\nY : %d", x, y);
     MessageBoxA(0,msg, "UltiNaruto Counter-Strike 2D v3.0", 0);
}

void gotoxy(int x, int y) {
    COORD pos = {x, y};
    HANDLE output = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleCursorPosition(output, pos);
}

void InitPlayer(int player_id, int x, int y, int health, int currentweaponid)
{
     Player[player_id].x = x;
     Player[player_id].y = y;
     Player[player_id].health = health;
     Player[player_id].isDead = false;
     Player[player_id].currentweaponid = currentweaponid;
}

void InitSpawnpoint(int spawn_id, int x, int y)
{
     spawnpoints[spawn_id].x = x;
     spawnpoints[spawn_id].y = y;
}

void InitWall(int x, int y)
{
     Walls[wall_id].x = x;
     Walls[wall_id].y = y;
     wall_id++;
}

void InitWeapon(char * name, int damage, int range)
{
     strcpy(WeaponMgr[weapon_count].name, name);
     WeaponMgr[weapon_count].damage = damage;
     WeaponMgr[weapon_count].range = range;
     weapon_count++;
}

void Shoot(int player_id,int enemy_id,int shoot_x,int shoot_y,int shoot_horizontal,int shoot_vertical)
{
     int i;
     if (shoot_horizontal == -1)
     {
          for(i=1;i<(WeaponMgr[Player[player_id].currentweaponid].range+1);i++)
          {
               if (shoot_x-i > LEFT_BORDER)
               {
                    if(i>1)
                    {
                     gotoxy(shoot_x-i+1,shoot_y);
                     cout << " ";
                    }
                    for (int j=0;j<(wall_count+1);j++)
                         if (Walls[j].x == shoot_x-i && Walls[j].y == shoot_y)
                              return;
                    if (Player[enemy_id].x == shoot_x-i && Player[2].y == shoot_y)
                    {
                         if (Player[enemy_id].health > 0)
                         {
                               if (i == 1)
                                   Player[enemy_id].health -= (int)(WeaponMgr[Player[player_id].currentweaponid].damage / 1.5);
                               else
                                   Player[enemy_id].health -= (int)(WeaponMgr[Player[player_id].currentweaponid].damage / i); 
                         }
                
                         return;
                    }
                    gotoxy(shoot_x-i,shoot_y);
                    cout << "-";
               }
               else
                   break;
               Sleep(20);
          }
                   
          gotoxy(shoot_x-i+1,shoot_y);
          cout << " ";
     }
     if (shoot_horizontal == 1)
     {
          for(i=1;i<(WeaponMgr[Player[player_id].currentweaponid].range+1);i++)
          {
               if (shoot_x+i < RIGHT_BORDER)
               {
                    if(i>1)
                    {
                     gotoxy(shoot_x+i-1,shoot_y);
                     cout << " ";
                    }
                    for (int j=0;j<(wall_count+1);j++)
                         if (Walls[j].x == shoot_x+i && Walls[j].y == shoot_y)
                              return;
                    if (Player[enemy_id].x == shoot_x+i && Player[2].y == shoot_y)
                    {
                         if (Player[enemy_id].health > 0)
                         {
                              if (i == 1)
                                   Player[enemy_id].health -= (int)(WeaponMgr[Player[player_id].currentweaponid].damage / 1.5);
                              else
                                   Player[enemy_id].health -= (int)(WeaponMgr[Player[player_id].currentweaponid].damage / i); // damage p2   
                         }

                         return;
                    }
                    gotoxy(shoot_x+i,shoot_y);
                    cout << "-";
               }
               else
                   break;
               Sleep(20);
          }
          gotoxy(shoot_x+i-1,shoot_y);
          cout << " ";
     }
     if (shoot_vertical == -1)
     {
          for(i=1;i<(WeaponMgr[Player[player_id].currentweaponid].range+1);i++)
          {
               if (shoot_y-i > TOP_BORDER)
               {
                    if(i>1)
                    {
                     gotoxy(shoot_x,shoot_y-i+1);
                     cout << " ";
                    }
                    for (int j=0;j<(wall_count+1);j++)
                         if (Walls[j].x == shoot_x && Walls[j].y == shoot_y-i)
                              return;
                    if (Player[enemy_id].x == shoot_x && Player[enemy_id].y == shoot_y-i)
                    {
                         if (Player[enemy_id].health > 0)
                         {
                               if (i == 1)
                                   Player[enemy_id].health -= (int)(WeaponMgr[Player[player_id].currentweaponid].damage / 1.5);
                               else
                                   Player[enemy_id].health -= (int)(WeaponMgr[Player[1].currentweaponid].damage / i);  
                         }
                            
                         return;
                    }
                    else
                        break;
                    gotoxy(shoot_x,shoot_y-i);
                    cout << "|";
               }
               Sleep(20);
          }
          gotoxy(shoot_x,shoot_y-i+1);
          cout << " ";
     }
     if (shoot_vertical == 1)
     {
          for(i=1;i<(WeaponMgr[Player[player_id].currentweaponid].range+1);i++)
          {
               if (shoot_y+i < BOTTOM_BORDER)
               {
                    if(i>1)
                    {
                     gotoxy(shoot_x,shoot_y+i-1);
                     cout << " ";
                    }
                    for (int j=0;j<(wall_count+1);j++)
                         if (Walls[j].x == shoot_x && Walls[j].y == shoot_y+i)
                              return;
                    if (Player[enemy_id].x == shoot_x && Player[enemy_id].y == shoot_y+i)
                    {
                         if (Player[enemy_id].health > 0)
                         {
                               if (i == 1)
                                   Player[enemy_id].health -= (int)(WeaponMgr[Player[player_id].currentweaponid].damage / 1.5);
                               else
                                   Player[enemy_id].health -= (int)(WeaponMgr[Player[player_id].currentweaponid].damage / i);  
                         }
                        
                         return;
                    }
               }
               else
                   break;
               Sleep(20);
          }
          gotoxy(shoot_x,shoot_y+i-1);
          cout << " ";
     }
}

void Render()
{
          system("cls"); 
          gotoxy(0,TOP_BORDER);
          cout << "+------------------------------------------------------------------------------+";
          for (int i=3; i<23 ;i++)
          {
               gotoxy(LEFT_BORDER,i);
               cout << "|";
               gotoxy(RIGHT_BORDER,i);
               cout << "|";
          }
          gotoxy(0,BOTTOM_BORDER);
          cout << "+------------------------------------------------------------------------------+";
          for(int i=0;i<(wall_count+1);i++)
          {
               gotoxy(Walls[i].x, Walls[i].y);
               printf("#");
          }
}

void Hotkeys()
{
            /*if (GetAsyncKeyState(VK_F2)<0)
               MessageBoxMyPos(Player[1].x, Player[1].y);*/

            if (GetAsyncKeyState(VK_ESCAPE)<0)
               ExitProcess(0);
     
            // Player 1

            if (GetAsyncKeyState(VK_SPACE)<0)
               Shoot(1,2,Player[1].x,Player[1].y,Player[1].horizontal,Player[1].vertical);

            if (GetAsyncKeyState(VK_Q)<0)
            {
               if (Player[1].x > LEFT_BORDER+1)
               {
                  for(int i=0;i<(wall_count+1);i++)
                     if ((Player[1].x - 1 == Walls[i].x && Player[1].y == Walls[i].y) || (Player[1].x - 1 == Player[2].x && Player[1].y == Player[2].y))
                         return;

                  gotoxy(Player[1].x, Player[1].y);
                  cout << " ";
                  Player[1].horizontal = -1;
                  Player[1].vertical = 0;
                  Player[1].x -= 1;
               }
            }
            if (GetAsyncKeyState(VK_D)<0)
            {
               if (Player[1].x < RIGHT_BORDER-1)
               {
                  for(int i=0;i<(wall_count+1);i++)
                     if ((Player[1].x + 1 == Walls[i].x && Player[1].y == Walls[i].y) || (Player[1].x + 1 == Player[2].x && Player[1].y == Player[2].y))
                        return;

                  gotoxy(Player[1].x, Player[1].y);
                  cout << " ";
                  Player[1].horizontal = 1;
                  Player[1].vertical = 0;
                  Player[1].x += 1;
               }
            }
            if (GetAsyncKeyState(VK_Z)<0)
            {
               if (Player[1].y > TOP_BORDER+1)
               {
                  for(int i=0;i<(wall_count+1);i++)             
                     if ((Player[1].x == Walls[i].x && Player[1].y - 1 == Walls[i].y) || (Player[1].x == Player[2].x && Player[1].y - 1 == Player[2].y))
                        return;

                  gotoxy(Player[1].x, Player[1].y);
                  cout << " ";
                  Player[1].horizontal = 0;
                  Player[1].vertical = -1;
                  Player[1].y -= 1;
               }
            }
            if (GetAsyncKeyState(VK_S)<0)
            {
               if (Player[1].y < BOTTOM_BORDER-1)
               {
                  for(int i=0;i<(wall_count+1);i++)
                     if ((Player[1].x == Walls[i].x && Player[1].y + 1 == Walls[i].y) || (Player[1].x == Player[2].x && Player[1].y + 1 == Player[2].y))
                        return;

                  gotoxy(Player[1].x, Player[1].y);
                  cout << " ";
                  Player[1].horizontal = 0;
                  Player[1].vertical = 1;
                  Player[1].y += 1;
               }
            }
            
            if (GetAsyncKeyState(VK_A)<0)
               if (Player[1].currentweaponid > 1)
                  Player[1].currentweaponid -= 1;

            if (GetAsyncKeyState(VK_E)<0)
               if (Player[1].currentweaponid < 10)
                  Player[1].currentweaponid += 1;
            
            // Player 2
            
            if (GetAsyncKeyState(VK_RCONTROL)<0)
               Shoot(2,1,Player[2].x,Player[2].y,Player[2].horizontal,Player[2].vertical);
            
            if (GetAsyncKeyState(VK_LEFT)<0)
            {
               if (Player[2].x > LEFT_BORDER+1)
               {
                  for(int i=0;i<(wall_count+1);i++)
                     if ((Player[2].x - 1 == Walls[i].x && Player[2].y == Walls[i].y) || (Player[2].x - 1 == Player[1].x && Player[2].y == Player[1].y))
                        return;

                  gotoxy(Player[2].x, Player[2].y);
                  cout << " ";
                  Player[2].horizontal = -1;
                  Player[2].vertical = 0;
                  Player[2].x -= 1;
               }
            }
            if (GetAsyncKeyState(VK_RIGHT)<0)
            {
               if (Player[2].x < RIGHT_BORDER-1)
               {
                  for(int i=0;i<(wall_count+1);i++)
                     if ((Player[2].x + 1 == Walls[i].x && Player[2].y == Walls[i].y) || (Player[2].x + 1 == Player[1].x && Player[2].y == Player[1].y))
                        return;

                  gotoxy(Player[2].x, Player[2].y);
                  cout << " ";
                  Player[2].horizontal = 1;
                  Player[2].vertical = 0;
                  Player[2].x += 1;
               }
            }
            if (GetAsyncKeyState(VK_UP)<0)
            {
               if (Player[2].y > TOP_BORDER+1)
               {
                  for(int i=0;i<(wall_count+1);i++)
                     if ((Player[2].x == Walls[i].x && Player[2].y - 1 == Walls[i].y) || (Player[2].x == Player[1].x && Player[2].y - 1 == Player[1].y))
                        return;

                  gotoxy(Player[2].x, Player[2].y);
                  cout << " ";
                  Player[2].horizontal = 0;
                  Player[2].vertical = -1;
                  Player[2].y -= 1;
               }
            }
            if (GetAsyncKeyState(VK_DOWN)<0)
            {
               if (Player[2].y < BOTTOM_BORDER-1)
               {
                  for(int i=0;i<(wall_count+1);i++)
                     if ((Player[2].x == Walls[i].x && Player[2].y + 1 == Walls[i].y) || (Player[2].x == Player[1].x && Player[2].y + 1 == Player[1].y))
                        return;

                  gotoxy(Player[2].x, Player[2].y);
                  cout << " ";
                  Player[2].horizontal = 0;
                  Player[2].vertical = 1;
                  Player[2].y += 1;
               }
            }
            
            if (GetAsyncKeyState(VK_L)<0)
               if (Player[2].currentweaponid > 1)
                  Player[2].currentweaponid -= 1;

            if (GetAsyncKeyState(VK_M)<0)
               if (Player[2].currentweaponid < 10)
                  Player[2].currentweaponid += 1;
}

int main(int argc, char *argv[])
{
    srand(time(NULL));
    SetConsoleTitle("UltiNaruto Counter-Strike 2D v3.0");
    cout << "Limite de Kills? (entre 20-100)\n";
    cin >> frag_limit;
    if (frag_limit < 20)
    {
        frag_limit = 20;
    }
    if (frag_limit > 100)
    {
        frag_limit = 100;
    }
    InitPlayer(1, 2, 6, 100, 1);
    InitPlayer(2, 77, 18, 100, 1);
    InitWeapon("M4A1", 100, 5);
    InitWeapon("Desert Eagle", 180, 2);
    InitWeapon("MP5", 76, 4);
    InitWeapon("Anaconda", 168, 2);
    InitWeapon("XM8", 94, 6);
    InitWeapon("AK-47", 116, 6);
    InitWeapon("Kriss Super V", 79, 5);
    InitWeapon("Knife", 90, 1);
    InitWeapon("M60", 106, 8);
    InitWeapon("P90", 68, 4);
    InitWall(4, 5);
    InitWall(4, 6);
    InitWall(4, 7);
    InitWall(4, 8);
    InitWall(4, 9);
    InitWall(4, 10);
    InitWall(5, 5);
    InitWall(6, 5);
    InitWall(7, 5);
    InitWall(8, 5);
    InitWall(4, 14);
    InitWall(4, 15);
    InitWall(4, 16);
    InitWall(4, 17);
    InitWall(4, 18);
    InitWall(4, 19);
    InitWall(5, 19);
    InitWall(6, 19);
    InitWall(7, 19);
    InitWall(8, 19);
    InitWall(8, 9);
    InitWall(8, 10);
    InitWall(8, 11);
    InitWall(8, 12);
    InitWall(8, 13);
    InitWall(8, 14);
    InitWall(8, 15);
    InitWall(9, 9);
    InitWall(10, 9);
    InitWall(9, 15);
    InitWall(10, 15);
    InitWall(75, 5);
    InitWall(75, 6);
    InitWall(75, 7);
    InitWall(75, 8);
    InitWall(75, 9);
    InitWall(75, 10);
    InitWall(74, 5);
    InitWall(73, 5);
    InitWall(72, 5);
    InitWall(71, 5);
    InitWall(75, 14);
    InitWall(75, 15);
    InitWall(75, 16);
    InitWall(75, 17);
    InitWall(75, 18);
    InitWall(75, 19);
    InitWall(74, 19);
    InitWall(73, 19);
    InitWall(72, 19);
    InitWall(71, 19);
    InitWall(71, 9);
    InitWall(71, 10);
    InitWall(71, 11);
    InitWall(71, 12);
    InitWall(71, 13);
    InitWall(71, 14);
    InitWall(71, 15);
    InitWall(70, 9);
    InitWall(69, 9);
    InitWall(70, 15);
    InitWall(69, 15);
    InitWall(37, 10);
    InitWall(38, 10);
    InitWall(39, 10);
    InitWall(40, 10);
    InitWall(41, 10);
    InitWall(37, 11);
    InitWall(37, 12);
    InitWall(37, 13);
    InitWall(41, 11);
    InitWall(41, 12);
    InitWall(41, 13);
    InitWall(37, 14);
    InitWall(38, 14);
    InitWall(39, 14);
    InitWall(40, 14);
    InitWall(41, 14);
    InitWall(39, 3);
    InitWall(39, 4);
    InitWall(39, 5);
    InitWall(39, 6);
    InitWall(39, 7);
    InitWall(39, 17);
    InitWall(39, 18);
    InitWall(39, 19);
    InitWall(39, 20);
    InitWall(39, 21);
    InitWall(11, 11);
    InitWall(12, 11);
    InitWall(13, 11);
    InitWall(14, 11);
    InitWall(15, 11);
    InitWall(16, 11);
    InitWall(17, 11);
    InitWall(18, 11);
    InitWall(19, 11);
    InitWall(20, 11);
    InitWall(11, 13);
    InitWall(12, 13);
    InitWall(13, 13);
    InitWall(14, 13);
    InitWall(15, 13);
    InitWall(16, 13);
    InitWall(17, 13);
    InitWall(18, 13);
    InitWall(19, 13);
    InitWall(20, 13);
    InitWall(68, 11);
    InitWall(67, 11);
    InitWall(66, 11);
    InitWall(65, 11);
    InitWall(64, 11);
    InitWall(63, 11);
    InitWall(62, 11);
    InitWall(61, 11);
    InitWall(60, 11);
    InitWall(59, 11);
    InitWall(68, 13);
    InitWall(67, 13);
    InitWall(66, 13);
    InitWall(65, 13);
    InitWall(64, 13);
    InitWall(63, 13);
    InitWall(62, 13);
    InitWall(61, 13);
    InitWall(60, 13);
    InitWall(59, 13);
    InitWall(50, 3);
    InitWall(50, 4);
    InitWall(50, 5);
    InitWall(50, 9);
    InitWall(50, 10);
    InitWall(50, 14);
    InitWall(50, 15);
    InitWall(50, 19);
    InitWall(50, 20);
    InitWall(50, 21);
    InitWall(28, 3);
    InitWall(28, 4);
    InitWall(28, 5);
    InitWall(28, 9);
    InitWall(28, 10);
    InitWall(28, 14);
    InitWall(28, 15);
    InitWall(28, 19);
    InitWall(28, 20);
    InitWall(28, 21);
    InitSpawnpoint(0,2,6);
    InitSpawnpoint(1,9,10);
    InitSpawnpoint(2,37,20);
    InitSpawnpoint(3,39,9);
    InitSpawnpoint(4,39,15);
    InitSpawnpoint(5,41,20);
    InitSpawnpoint(6,70,14);
    InitSpawnpoint(7,77,18);
    Render();
    while(!end_game)
    {       
            gotoxy(21,0);
            cout << "   ";
            gotoxy(74,0);
            cout << "   ";
            gotoxy(0,0);
            cout << "Player 1 :      HP : " << Player[1].health << "                             Player 2 :      HP : " << Player[2].health << "\nKills : " << Player[1].kills << "     Deaths : " << Player[1].deaths << "                             Kills : " << Player[2].kills << "     Deaths : " << Player[2].deaths;
            gotoxy(17,23);
            cout << "                    ";
            gotoxy(52,23);
            cout << "                          ";
            gotoxy(0,23);
            cout << "Current Weapon : " << WeaponMgr[Player[1].currentweaponid].name << "                  " << "Current Weapon : " << WeaponMgr[Player[2].currentweaponid].name;
            int random = (rand()%8);
            Hotkeys();
            if (Player[1].isDead == false)
            {
               gotoxy(Player[1].x, Player[1].y);
               cout << "1";
            }
            if (Player[2].isDead == false)
            {
               gotoxy(Player[2].x, Player[2].y);
               cout << "2";
            }
            for (int i=1;i<3;i++)
            {
                if (Player[i].kills == frag_limit)
                {
                     winner_id = i;
                     end_game = true;
                }
                if (Player[i].health <= 0)
                {
                     gotoxy(Player[i].x, Player[i].y);
                     cout << " ";
                     int j;
                     if (i==1)
                        j = 2;
                     else if (i==2)
                        j = 1;
                     Player[j].kills += 1;
                     Player[i].deaths += 1;
                     InitPlayer(i, spawnpoints[random].x, spawnpoints[random].y, 100, Player[i].currentweaponid);
                }
            }
            
           Sleep(100); // Rafraichissement tous les 100 ms
    }
    while (end_game)
    {
          system("cls");
          gotoxy(0,0);
          cout << "Player " << winner_id << " won!";
          Sleep(100); // Rafraichissement tous les 100 ms
    }
    return EXIT_SUCCESS;
}
